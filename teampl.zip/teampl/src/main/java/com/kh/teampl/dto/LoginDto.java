package com.kh.teampl.dto;

import lombok.Data;

@Data
public class LoginDto {
	private String member_id;
	private String member_pw;
}
